<div class="content-none">

    <div class="container">
        <h1>Nothing Found <i class="fa fa-frown-o"></i></h1>
        <hr>
        <p><strong>404 Error. </strong>The page is missing, or it doesn't exist.</p>
    </div>
</div>