<?php

wp_nonce_field( 'save_metaboxes', 'blanket_metabox_nonce');
 ?>